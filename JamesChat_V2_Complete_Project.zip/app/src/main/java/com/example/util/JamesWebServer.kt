package com.example.util

import android.content.Context
import com.example.data.model.MessageType
import com.example.data.repository.JamesChatRepository
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpHandler
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.util.concurrent.Executors

object JamesWebServer {
    private var server: HttpServer? = null
    private val scope = CoroutineScope(Dispatchers.IO)
    private var repositoryRef: JamesChatRepository? = null

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _serverUrl = MutableStateFlow("http://127.0.0.1:8080")
    val serverUrl: StateFlow<String> = _serverUrl.asStateFlow()

    private val _connectedClientsCount = MutableStateFlow(0)
    val connectedClientsCount: StateFlow<Int> = _connectedClientsCount.asStateFlow()

    fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        return address.hostAddress ?: "127.0.0.1"
                    }
                }
            }
        } catch (_: Exception) {
        }
        return "127.0.0.1"
    }

    fun start(context: Context, repository: JamesChatRepository, port: Int = 8080): Boolean {
        if (_isRunning.value) return true
        repositoryRef = repository
        return try {
            val ip = getLocalIpAddress()
            val address = InetSocketAddress(port)
            server = HttpServer.create(address, 0).apply {
                executor = Executors.newFixedThreadPool(4)
                createContext("/", WebAppHandler(repository))
                createContext("/api/conversations", ConversationsApiHandler(repository))
                createContext("/api/messages", MessagesApiHandler(repository))
                createContext("/api/send", SendMessageApiHandler(repository, context))
                createContext("/api/status", StatusApiHandler(repository))
                start()
            }
            _serverUrl.value = "http://127.0.0.1:$port"
            _isRunning.value = true
            true
        } catch (e: Exception) {
            e.printStackTrace()
            _isRunning.value = false
            false
        }
    }

    fun stop() {
        try {
            server?.stop(0)
            server = null
            _isRunning.value = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private class WebAppHandler(private val repository: JamesChatRepository) : HttpHandler {
        override fun handle(exchange: HttpExchange) {
            if (exchange.requestMethod.equals("GET", ignoreCase = true)) {
                _connectedClientsCount.value = maxOf(1, _connectedClientsCount.value)
                val html = generateWebHtml()
                val bytes = html.toByteArray(Charsets.UTF_8)
                exchange.responseHeaders.set("Content-Type", "text/html; charset=UTF-8")
                exchange.sendResponseHeaders(200, bytes.size.toLong())
                val os: OutputStream = exchange.responseBody
                os.write(bytes)
                os.close()
            } else {
                exchange.sendResponseHeaders(405, -1)
            }
        }
    }

    private class ConversationsApiHandler(private val repository: JamesChatRepository) : HttpHandler {
        override fun handle(exchange: HttpExchange) {
            exchange.responseHeaders.set("Content-Type", "application/json; charset=UTF-8")
            exchange.responseHeaders.set("Access-Control-Allow-Origin", "*")
            val conversations = runBlocking {
                repository.dao.getAllConversationsFlow().firstOrNull() ?: emptyList()
            }
            val array = JSONArray()
            conversations.forEach { conv ->
                val obj = JSONObject().apply {
                    put("id", conv.id)
                    put("title", conv.title)
                    put("avatarUrl", conv.avatarUrl)
                    put("isGroup", conv.isGroup)
                    put("lastMessage", conv.lastMessageSnippet)
                    put("lastMessageTime", conv.lastMessageTimestamp)
                    put("unreadCount", conv.unreadCount)
                }
                array.put(obj)
            }
            val bytes = array.toString().toByteArray(Charsets.UTF_8)
            exchange.sendResponseHeaders(200, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
    }

    private class MessagesApiHandler(private val repository: JamesChatRepository) : HttpHandler {
        override fun handle(exchange: HttpExchange) {
            exchange.responseHeaders.set("Content-Type", "application/json; charset=UTF-8")
            exchange.responseHeaders.set("Access-Control-Allow-Origin", "*")
            val query = exchange.requestURI.query ?: ""
            val convId = query.split("&")
                .firstOrNull { it.startsWith("conversationId=") }
                ?.substringAfter("conversationId=") ?: ""

            val messages = if (convId.isNotEmpty()) {
                runBlocking {
                    repository.dao.getMessagesFlow(convId).firstOrNull() ?: emptyList()
                }
            } else emptyList()

            val array = JSONArray()
            messages.forEach { msg ->
                val obj = JSONObject().apply {
                    put("id", msg.id)
                    put("senderId", msg.senderId)
                    put("senderUsername", msg.senderUsername)
                    put("text", msg.text)
                    put("timestamp", msg.timestamp)
                    put("status", msg.status)
                    put("type", msg.type)
                    put("mediaUrl", msg.mediaUrl ?: "")
                }
                array.put(obj)
            }
            val bytes = array.toString().toByteArray(Charsets.UTF_8)
            exchange.sendResponseHeaders(200, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
    }

    private class SendMessageApiHandler(
        private val repository: JamesChatRepository,
        private val context: Context
    ) : HttpHandler {
        override fun handle(exchange: HttpExchange) {
            exchange.responseHeaders.set("Access-Control-Allow-Origin", "*")
            exchange.responseHeaders.set("Access-Control-Allow-Headers", "Content-Type")
            if (exchange.requestMethod.equals("OPTIONS", ignoreCase = true)) {
                exchange.sendResponseHeaders(204, -1)
                return
            }

            if (exchange.requestMethod.equals("POST", ignoreCase = true)) {
                val reader = BufferedReader(InputStreamReader(exchange.requestBody, Charsets.UTF_8))
                val body = reader.readText()
                val json = JSONObject(body)
                val convId = json.optString("conversationId")
                val text = json.optString("text")
                val mediaTypeStr = json.optString("type")
                val mediaUrl = json.optString("mediaUrl")

                if (convId.isNotEmpty()) {
                    scope.launch {
                        if (mediaTypeStr == "PHOTO" && mediaUrl.isNotEmpty()) {
                            repository.sendMediaMessage(
                                conversationId = convId,
                                type = MessageType.PHOTO,
                                mediaUrl = mediaUrl,
                                caption = text.ifEmpty { "📷 Foto voye depi sou Web" }
                            )
                        } else if (mediaTypeStr == "AUDIO") {
                            repository.sendMediaMessage(
                                conversationId = convId,
                                type = MessageType.AUDIO,
                                mediaUrl = "https://actions.google.com/sounds/v1/water/rain_heavy.ogg",
                                durationSeconds = 12,
                                caption = "🎤 Nòt vokal James Web"
                            )
                        } else if (text.isNotEmpty()) {
                            repository.sendTextMessage(convId, text)
                        }

                        JamesNotificationManager.showMessageNotification(
                            context = context,
                            senderName = "James Web",
                            messageText = text.ifEmpty { "Nouvo medya voye depi sou Web" },
                            conversationId = convId
                        )
                    }
                    val resp = JSONObject().put("success", true).toString().toByteArray(Charsets.UTF_8)
                    exchange.responseHeaders.set("Content-Type", "application/json")
                    exchange.sendResponseHeaders(200, resp.size.toLong())
                    exchange.responseBody.use { it.write(resp) }
                } else {
                    exchange.sendResponseHeaders(400, -1)
                }
            } else {
                exchange.sendResponseHeaders(405, -1)
            }
        }
    }

    private class StatusApiHandler(private val repository: JamesChatRepository) : HttpHandler {
        override fun handle(exchange: HttpExchange) {
            exchange.responseHeaders.set("Content-Type", "application/json")
            exchange.responseHeaders.set("Access-Control-Allow-Origin", "*")
            val user = repository.currentUser.value
            val displayName = ((user?.firstName ?: "") + " " + (user?.lastName ?: "")).trim().ifEmpty { "Itilizatè" }
            val obj = JSONObject().apply {
                put("online", true)
                put("appName", "James Chat Web")
                put("user", JSONObject().apply {
                    put("id", user?.id ?: "")
                    put("name", displayName)
                    put("username", user?.username ?: "")
                    put("avatarUrl", user?.avatarUrl ?: "")
                    put("isVerified", user?.isVerified ?: false)
                })
            }
            val bytes = obj.toString().toByteArray(Charsets.UTF_8)
            exchange.sendResponseHeaders(200, bytes.size.toLong())
            exchange.responseBody.use { it.write(bytes) }
        }
    }

    private fun generateWebHtml(): String {
        return """
<!DOCTYPE html>
<html lang="ht">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>James Chat Web • WhatsApp Style</title>
  <style>
    :root {
      --bg-dark: #0b141a;
      --panel-dark: #111b21;
      --header-dark: #202c33;
      --text-dark: #e9edef;
      --text-muted: #8696a0;
      --green: #00a884;
      --green-dark: #005c4b;
      --bubble-in: #202c33;
      --border-dark: #222d34;
      --input-bg: #2a3942;
    }
    .light-theme {
      --bg-dark: #eae6df;
      --panel-dark: #ffffff;
      --header-dark: #f0f2f5;
      --text-dark: #111b21;
      --text-muted: #667781;
      --green: #008069;
      --green-dark: #d9fdd3;
      --bubble-in: #ffffff;
      --border-dark: #e9edef;
      --input-bg: #ffffff;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
    body { background-color: var(--bg-dark); color: var(--text-dark); display: flex; height: 100vh; width: 100vw; overflow: hidden; }
    
    /* SIDEBAR */
    #sidebar { width: 360px; min-width: 280px; border-right: 1px solid var(--border-dark); background-color: var(--panel-dark); display: flex; flex-direction: column; height: 100%; }
    .header { padding: 12px 16px; background-color: var(--header-dark); display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border-dark); }
    .header-user { display: flex; align-items: center; gap: 10px; font-weight: 700; font-size: 15px; color: var(--green); }
    .header-icons { display: flex; gap: 8px; }
    .header-btn { background: none; border: none; font-size: 18px; cursor: pointer; color: var(--text-muted); padding: 6px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
    .header-btn:hover { background-color: rgba(255,255,255,0.1); color: var(--green); }
    
    .search-box { padding: 8px 12px; background-color: var(--panel-dark); display: flex; align-items: center; border-bottom: 1px solid var(--border-dark); }
    .search-input { width: 100%; padding: 8px 12px; background: var(--header-dark); border: none; border-radius: 8px; color: var(--text-dark); font-size: 13px; outline: none; }
    
    .chat-list { flex: 1; overflow-y: auto; }
    .chat-item { display: flex; align-items: center; padding: 10px 14px; cursor: pointer; border-bottom: 1px solid rgba(134,150,160,0.1); transition: background 0.15s; }
    .chat-item:hover, .chat-item.active { background-color: rgba(134,150,160,0.18); }
    .chat-avatar { width: 44px; height: 44px; border-radius: 50%; background: #1f5068; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; margin-right: 12px; flex-shrink: 0; position: relative; }
    .chat-avatar.online::after { content: ''; position: absolute; bottom: 2px; right: 2px; width: 10px; height: 10px; background-color: #25d366; border-radius: 50%; border: 2px solid var(--panel-dark); }
    .chat-details { flex: 1; min-width: 0; }
    .chat-top-row { display: flex; justify-content: space-between; align-items: center; }
    .chat-name { font-weight: 600; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--text-dark); }
    .chat-time { font-size: 11px; color: var(--text-muted); }
    .chat-last-msg { font-size: 12px; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 3px; }
    
    /* MAIN CHAT AREA */
    #main-chat { flex: 1; display: flex; flex-direction: column; background-color: var(--bg-dark); height: 100%; position: relative; }
    .chat-topbar { padding: 10px 16px; background-color: var(--header-dark); display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--border-dark); }
    .chat-topbar-left { display: flex; align-items: center; cursor: pointer; }
    .topbar-info h3 { font-size: 15px; font-weight: 600; color: var(--text-dark); }
    .topbar-info span { font-size: 11px; color: var(--green); }
    .chat-topbar-actions { display: flex; gap: 10px; }
    
    .messages-area { flex: 1; padding: 16px; overflow-y: auto; display: flex; flex-direction: column; gap: 8px; background: var(--bg-dark); }
    .message { max-width: 72%; padding: 8px 12px; border-radius: 10px; font-size: 14px; line-height: 1.4; word-break: break-word; position: relative; }
    .msg-incoming { align-self: flex-start; background-color: var(--bubble-in); color: var(--text-dark); border-bottom-left-radius: 2px; }
    .msg-outgoing { align-self: flex-end; background-color: var(--green-dark); color: var(--text-dark); border-bottom-right-radius: 2px; }
    .msg-meta { font-size: 10px; color: var(--text-muted); text-align: right; margin-top: 4px; display: flex; align-items: center; justify-content: flex-end; gap: 4px; }
    .msg-media { max-width: 100%; border-radius: 8px; margin-top: 4px; display: block; }
    
    /* EMOJI BAR & INPUT */
    .emoji-picker-bar { display: none; background: var(--header-dark); padding: 8px 12px; border-top: 1px solid var(--border-dark); gap: 10px; overflow-x: auto; }
    .emoji-item { font-size: 20px; cursor: pointer; user-select: none; transition: transform 0.1s; }
    .emoji-item:hover { transform: scale(1.25); }
    
    .chat-input-area { padding: 10px 14px; background-color: var(--header-dark); display: flex; align-items: center; gap: 8px; border-top: 1px solid var(--border-dark); }
    .action-icon-btn { background: none; border: none; font-size: 20px; cursor: pointer; color: var(--text-muted); padding: 6px; border-radius: 50%; }
    .action-icon-btn:hover { color: var(--green); }
    .input-text { flex: 1; padding: 10px 14px; background-color: var(--input-bg); border: 1px solid var(--border-dark); border-radius: 20px; color: var(--text-dark); font-size: 14px; outline: none; }
    .send-btn { background: var(--green); color: #fff; border: none; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: 0.2s; font-size: 18px; }
    .send-btn:hover { opacity: 0.9; }
    
    .empty-state { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; color: var(--text-muted); text-align: center; padding: 24px; }
    .empty-icon { font-size: 64px; margin-bottom: 12px; color: var(--green); }
    .empty-state h3 { font-size: 20px; color: var(--text-dark); margin-bottom: 8px; }
    
    /* MOBILE RESPONSIVE (When viewed inside phone) */
    @media (max-width: 600px) {
      #sidebar { width: 100%; }
      #sidebar.chat-open { display: none; }
      #main-chat { display: none; }
      #main-chat.chat-open { display: flex; width: 100%; }
      .back-to-list-btn { display: inline-block !important; }
    }
    .back-to-list-btn { display: none; margin-right: 8px; font-size: 18px; cursor: pointer; background: none; border: none; color: var(--text-muted); }
  </style>
</head>
<body>
  <!-- SIDEBAR -->
  <div id="sidebar">
    <div class="header">
      <div class="header-user">
        <span>💬</span>
        <span id="user-display-name">James Web</span>
      </div>
      <div class="header-icons">
        <button class="header-btn" id="theme-toggle-btn" title="Chanje Tèm (Nwa/Klè)">🌓</button>
        <button class="header-btn" id="refresh-chats-btn" title="Rafrechi">🔄</button>
      </div>
    </div>
    <div class="search-box">
      <input type="text" id="search-input" class="search-input" placeholder="🔍 Chèche yon diskisyon...">
    </div>
    <div class="chat-list" id="conversations-list">
      <div style="padding: 20px; text-align: center; color: var(--text-muted);">Chaje diskisyon ou yo...</div>
    </div>
  </div>

  <!-- MAIN CHAT AREA -->
  <div id="main-chat">
    <div class="chat-topbar" id="chat-header" style="display: none;">
      <div class="chat-topbar-left">
        <button class="back-to-list-btn" id="back-to-list">⬅️</button>
        <div class="chat-avatar online" id="header-avatar" style="width: 38px; height: 38px; margin-right: 10px;"></div>
        <div class="topbar-info">
          <h3 id="header-title">Tit</h3>
          <span>● An liy sou James Chat</span>
        </div>
      </div>
      <div class="chat-topbar-actions">
        <button class="action-icon-btn" onclick="triggerCall('vocal')" title="Apèl Vokal">📞</button>
        <button class="action-icon-btn" onclick="triggerCall('video')" title="Apèl Vidéyo">📹</button>
      </div>
    </div>

    <!-- EMPTY PLACEHOLDER -->
    <div class="empty-state" id="empty-state">
      <div class="empty-icon">💬</div>
      <h3>Byenvini sou James Chat Web !</h3>
      <p>Klike sou yon diskisyon sou bò gòch la pou kòmanse voye mesaj, foto, ak emojis an dirèk tankou sou WhatsApp Web.</p>
    </div>

    <!-- MESSAGES LIST -->
    <div class="messages-area" id="messages-container" style="display: none;"></div>

    <!-- EMOJI PICKER BAR -->
    <div class="emoji-picker-bar" id="emoji-bar">
      <span class="emoji-item" onclick="insertEmoji('😀')">😀</span>
      <span class="emoji-item" onclick="insertEmoji('😂')">😂</span>
      <span class="emoji-item" onclick="insertEmoji('😍')">😍</span>
      <span class="emoji-item" onclick="insertEmoji('🔥')">🔥</span>
      <span class="emoji-item" onclick="insertEmoji('👍')">👍</span>
      <span class="emoji-item" onclick="insertEmoji('👏')">👏</span>
      <span class="emoji-item" onclick="insertEmoji('🙏')">🙏</span>
      <span class="emoji-item" onclick="insertEmoji('❤️')">❤️</span>
      <span class="emoji-item" onclick="insertEmoji('🎉')">🎉</span>
      <span class="emoji-item" onclick="insertEmoji('💯')">💯</span>
      <span class="emoji-item" onclick="insertEmoji('🚀')">🚀</span>
      <span class="emoji-item" onclick="insertEmoji('🇭🇹')">🇭🇹</span>
    </div>

    <!-- INPUT AREA -->
    <div class="chat-input-area" id="chat-input-container" style="display: none;">
      <button class="action-icon-btn" id="emoji-toggle-btn" title="Emojis">😊</button>
      <button class="action-icon-btn" id="attach-photo-btn" title="Atache Foto">📎</button>
      <input type="text" id="msg-input" class="input-text" placeholder="Ekri yon mesaj..." autofocus>
      <button class="action-icon-btn" id="voice-note-btn" title="Nòt Vokal">🎤</button>
      <button class="send-btn" id="send-button" title="Voye">➤</button>
    </div>
  </div>

  <script>
    let activeConversationId = null;
    let conversations = [];
    let currentUserId = "";

    // Toggle Theme
    document.getElementById('theme-toggle-btn').addEventListener('click', () => {
      document.body.classList.toggle('light-theme');
    });

    // Toggle Emoji Bar
    document.getElementById('emoji-toggle-btn').addEventListener('click', () => {
      const bar = document.getElementById('emoji-bar');
      bar.style.display = bar.style.display === 'flex' ? 'none' : 'flex';
    });

    function insertEmoji(em) {
      const input = document.getElementById('msg-input');
      input.value += em;
      input.focus();
    }

    // Attach Photo (Quick photo sender)
    document.getElementById('attach-photo-btn').addEventListener('click', async () => {
      if (!activeConversationId) return;
      const photoUrls = [
        "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=500",
        "https://images.unsplash.com/photo-1518770660439-4636190af475?w=500",
        "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500"
      ];
      const selected = photoUrls[Math.floor(Math.random() * photoUrls.length)];
      await fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId: activeConversationId,
          type: "PHOTO",
          mediaUrl: selected,
          text: "📷 Foto pataje sou James Web"
        })
      });
      await loadMessages();
      await loadConversations();
    });

    // Voice Note simulation
    document.getElementById('voice-note-btn').addEventListener('click', async () => {
      if (!activeConversationId) return;
      await fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId: activeConversationId,
          type: "AUDIO",
          text: "🎤 Nòt vokal (12s)"
        })
      });
      await loadMessages();
      await loadConversations();
    });

    function triggerCall(type) {
      alert((type === 'video' ? '📹 Apèl Vidéyo' : '📞 Apèl Vokal') + ' lanse sou James Chat !');
    }

    // Back to list on mobile
    document.getElementById('back-to-list').addEventListener('click', () => {
      document.getElementById('sidebar').classList.remove('chat-open');
      document.getElementById('main-chat').classList.remove('chat-open');
    });

    async function loadStatus() {
      try {
        const res = await fetch('/api/status');
        const data = await res.json();
        currentUserId = data.user.id;
        document.getElementById('user-display-name').innerText = data.user.name || "James Web";
      } catch (e) {
        console.error(e);
      }
    }

    async function loadConversations() {
      try {
        const res = await fetch('/api/conversations');
        conversations = await res.json();
        renderConversations(conversations);
      } catch (e) {
        console.error(e);
      }
    }

    function renderConversations(list) {
      const container = document.getElementById('conversations-list');
      if (!list || list.length === 0) {
        container.innerHTML = '<div style="padding: 20px; text-align: center; color: var(--text-muted);">Pa gen okenn diskisyon pou kounye a.</div>';
        return;
      }
      container.innerHTML = list.map(function(c) {
        const activeClass = (c.id === activeConversationId) ? 'active' : '';
        const initial = (c.title || 'J').charAt(0).toUpperCase();
        const time = c.lastMessageTime ? new Date(c.lastMessageTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
        return '<div class="chat-item ' + activeClass + '" onclick="selectConversation(\'' + c.id + '\')">' +
          '<div class="chat-avatar online">' + initial + '</div>' +
          '<div class="chat-details">' +
            '<div class="chat-top-row">' +
              '<div class="chat-name">' + escapeHtml(c.title || '') + '</div>' +
              '<div class="chat-time">' + time + '</div>' +
            '</div>' +
            '<div class="chat-last-msg">' + escapeHtml(c.lastMessage || 'Klike pou w kòmanse...') + '</div>' +
          '</div>' +
        '</div>';
      }).join('');
    }

    async function selectConversation(id) {
      activeConversationId = id;
      const conv = conversations.find(function(c) { return c.id === id; });
      if (!conv) return;

      document.getElementById('empty-state').style.display = 'none';
      document.getElementById('chat-header').style.display = 'flex';
      document.getElementById('messages-container').style.display = 'flex';
      document.getElementById('chat-input-container').style.display = 'flex';

      document.getElementById('header-title').innerText = conv.title || '';
      document.getElementById('header-avatar').innerText = (conv.title || 'J').charAt(0).toUpperCase();

      // Mobile responsive toggle
      document.getElementById('sidebar').classList.add('chat-open');
      document.getElementById('main-chat').classList.add('chat-open');

      renderConversations(conversations);
      await loadMessages();
      document.getElementById('msg-input').focus();
    }

    async function loadMessages() {
      if (!activeConversationId) return;
      try {
        const res = await fetch('/api/messages?conversationId=' + encodeURIComponent(activeConversationId));
        const messages = await res.json();
        const container = document.getElementById('messages-container');
        container.innerHTML = messages.map(function(m) {
          const isMe = (m.senderId === currentUserId);
          const time = new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          const cssClass = isMe ? 'msg-outgoing' : 'msg-incoming';
          const checks = isMe ? '✓✓' : '';
          let mediaHtml = '';
          if (m.mediaUrl && m.type === 'PHOTO') {
            mediaHtml = '<img src="' + escapeHtml(m.mediaUrl) + '" class="msg-media" style="max-height: 200px;">';
          }
          return '<div class="message ' + cssClass + '">' +
            mediaHtml +
            '<div>' + escapeHtml(m.text || '') + '</div>' +
            '<div class="msg-meta">' + time + ' <span style="color:#53bdeb">' + checks + '</span></div>' +
          '</div>';
        }).join('');
        container.scrollTop = container.scrollHeight;
      } catch (e) {
        console.error(e);
      }
    }

    async function sendMessage() {
      const input = document.getElementById('msg-input');
      const text = input.value.trim();
      if (!text || !activeConversationId) return;

      input.value = '';
      try {
        await fetch('/api/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ conversationId: activeConversationId, text: text })
        });
        await loadMessages();
        await loadConversations();
      } catch (e) {
        alert('Erè nan voye mesaj la: ' + e);
      }
    }

    document.getElementById('send-button').addEventListener('click', sendMessage);
    document.getElementById('msg-input').addEventListener('keydown', function(e) {
      if (e.key === 'Enter') sendMessage();
    });

    document.getElementById('search-input').addEventListener('input', function(e) {
      const q = e.target.value.toLowerCase();
      const filtered = conversations.filter(function(c) {
        return (c.title || '').toLowerCase().indexOf(q) !== -1;
      });
      renderConversations(filtered);
    });

    document.getElementById('refresh-chats-btn').addEventListener('click', () => {
      loadConversations();
      if (activeConversationId) loadMessages();
    });

    function escapeHtml(text) {
      const div = document.createElement('div');
      div.innerText = text;
      return div.innerHTML;
    }

    loadStatus().then(loadConversations);
    setInterval(function() {
      loadConversations();
      if (activeConversationId) loadMessages();
    }, 2500);
  </script>
</body>
</html>
        """.trimIndent()
    }
}
