package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdminPermission
import com.example.data.model.AppLanguage
import com.example.data.model.UserEntity
import com.example.data.repository.AdminAnalytics
import com.example.data.repository.JamesChatRepository
import com.example.ui.components.AvatarWithStatus
import com.example.ui.components.JamesTeamMemberBadge
import com.example.ui.components.JamesVBadge
import com.example.ui.theme.JamesBluePrimary
import com.example.ui.theme.JamesErrorRed
import com.example.ui.theme.JamesOnlineGreen
import com.example.ui.theme.JamesWarningAmber
import com.example.util.JamesI18n
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    repository: JamesChatRepository,
    currentLang: AppLanguage,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Vue Générale", "Utilisateurs", "Badges V", "Modération", "Équipe (7)")

    var analytics by remember { mutableStateOf<AdminAnalytics?>(null) }
    val allUsers by repository.dao.getAllUsersFlow().collectAsState(initial = emptyList())
    val verifiedLogs by repository.dao.getAllVerifiedBadgeLogsFlow().collectAsState(initial = emptyList())

    LaunchedEffect(Unit) {
        analytics = repository.getAdminAnalytics()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(JamesI18n.t("admin_panel", currentLang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_btn")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }

            when (selectedTab) {
                0 -> AdminOverviewTab(analytics = analytics)
                1 -> AdminUsersManagementTab(users = allUsers, repository = repository)
                2 -> AdminBadgesTab(users = allUsers, repository = repository)
                3 -> AdminModerationTab(repository = repository)
                4 -> AdminTeamTab()
            }
        }
    }
}

@Composable
fun AdminOverviewTab(analytics: AdminAnalytics?) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(text = "Indicateurs Clés de Performance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatCard(
                    title = "Utilisateurs",
                    value = "${analytics?.totalUsers ?: 0}",
                    color = JamesBluePrimary,
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    title = "Actifs aujourd'hui",
                    value = "${analytics?.activeUsers ?: 0}",
                    color = JamesOnlineGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatCard(
                    title = "Badges V Actifs",
                    value = "${analytics?.verifiedBadges ?: 0}",
                    color = Color(0xFF7C3AED),
                    modifier = Modifier.weight(1f)
                )
                AdminStatCard(
                    title = "Chaînes Publiques",
                    value = "${analytics?.totalChannels ?: 0}",
                    color = Color(0xFF0D9488),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Santé du Réseau & Sécurité", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "• Signalements en attente : ${analytics?.itemsUnderReview ?: 0}", fontSize = 13.sp)
                    Text(text = "• Comptes suspendus/bannis : ${analytics?.suspendedAccounts ?: 0}", fontSize = 13.sp)
                    Text(text = "• Chiffrement de bout en bout : ACTIF (100%)", fontSize = 13.sp, color = JamesOnlineGreen)
                }
            }
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, fontSize = 12.sp, color = color, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 24.sp, fontWeight = FontWeight.Black, color = color)
        }
    }
}

@Composable
fun AdminUsersManagementTab(
    users: List<UserEntity>,
    repository: JamesChatRepository
) {
    val scope = rememberCoroutineScope()
    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(users, searchQuery) {
        if (searchQuery.isBlank()) users else {
            val q = searchQuery.lowercase().trim()
            users.filter { it.username.lowercase().contains(q) || it.email.lowercase().contains(q) }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Rechercher un utilisateur...") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(12.dp)
        )

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filtered) { user ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AvatarWithStatus(
                        name = user.username.ifEmpty { user.email },
                        avatarUrl = user.avatarUrl,
                        size = 46.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "@${user.username}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            if (user.isVerified) {
                                Spacer(modifier = Modifier.width(4.dp))
                                JamesVBadge(size = 14.dp)
                            }
                        }
                        Text(text = user.email, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "Rôle: ${user.role}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }

                    if (!user.isBanned) {
                        OutlinedButton(
                            onClick = {
                                scope.launch { repository.adminBanUser(user.id, true) }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = JamesErrorRed)
                        ) {
                            Text("Bannir", fontSize = 11.sp)
                        }
                    } else {
                        Button(
                            onClick = {
                                scope.launch { repository.adminBanUser(user.id, false) }
                            }
                        ) {
                            Text("Débannir", fontSize = 11.sp)
                        }
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
            }
        }
    }
}

@Composable
fun AdminBadgesTab(
    users: List<UserEntity>,
    repository: JamesChatRepository
) {
    val scope = rememberCoroutineScope()
    var selectedUser by remember { mutableStateOf<UserEntity?>(null) }
    var badgeReason by remember { mutableStateOf("") }
    var showGrantDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Gestion Officielle des Badges de Vérification (V)",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            modifier = Modifier.padding(16.dp)
        )

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(users) { user ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AvatarWithStatus(name = user.username, avatarUrl = user.avatarUrl, size = 46.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "@${user.username}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            if (user.isVerified) {
                                Spacer(modifier = Modifier.width(4.dp))
                                JamesVBadge(size = 14.dp)
                            }
                        }
                        Text(text = if (user.isVerified) "Statut : Vérifié ✓" else "Non vérifié", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    if (user.isVerified) {
                        OutlinedButton(
                            onClick = {
                                scope.launch { repository.revokeVerifiedBadge(user.id, "Révocation admin") }
                            }
                        ) {
                            Text("Révoquer", fontSize = 11.sp)
                        }
                    } else {
                        Button(
                            onClick = {
                                selectedUser = user
                                showGrantDialog = true
                            }
                        ) {
                            Text("Attribuer V", fontSize = 11.sp)
                        }
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
            }
        }
    }

    if (showGrantDialog && selectedUser != null) {
        AlertDialog(
            onDismissRequest = { showGrantDialog = false },
            title = { Text("Attribuer le badge V à @${selectedUser?.username}") },
            text = {
                OutlinedTextField(
                    value = badgeReason,
                    onValueChange = { badgeReason = it },
                    label = { Text("Motif officiel (ex: Personnalité publique, artiste, VIP)") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            repository.grantVerifiedBadge(selectedUser!!.id, "Officiel", badgeReason)
                            showGrantDialog = false
                            badgeReason = ""
                        }
                    }
                ) {
                    Text("Confirmer l'attribution")
                }
            },
            dismissButton = {
                TextButton(onClick = { showGrantDialog = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
fun AdminModerationTab(repository: JamesChatRepository) {
    val dossiers by repository.dao.getAllModerationDossiersFlow().collectAsState(initial = emptyList())
    val userReports by repository.dao.getAllReportsFlow().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    if (dossiers.isEmpty() && userReports.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text = "Aucun signalement en attente. Tout est propre !", color = JamesOnlineGreen, fontWeight = FontWeight.Bold)
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            // User Reports Section
            if (userReports.isNotEmpty()) {
                item {
                    Text(
                        text = "SIGNALEMENTS DES UTILISATEURS (${userReports.count { it.status == "PENDING" }} en attente)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                items(userReports) { report ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (report.status == "PENDING") MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Type: ${report.targetType}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    text = report.status,
                                    color = if (report.status == "PENDING") JamesWarningAmber else JamesOnlineGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Signalé par: @${report.reporterUsername}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "Cible: @${report.reportedUsername}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(text = "Motif: ${report.reason}", fontSize = 13.sp, color = JamesErrorRed, fontWeight = FontWeight.Medium)
                            if (report.details.isNotEmpty()) {
                                Text(text = "Détails: ${report.details}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            if (report.status == "PENDING") {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                repository.warnUser(report.reportedUserId, "Avertissement suite à signalement: ${report.reason}")
                                                repository.updateReportStatus(report.id, "AVERTISSEMENT_DONNÉ")
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = JamesWarningAmber)
                                    ) {
                                        Text("Avertir (+1)", fontSize = 11.sp, color = Color.Black)
                                    }
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                repository.suspendUser(report.reportedUserId, 86400000L, "Suspension suite à signalement: ${report.reason}")
                                                repository.updateReportStatus(report.id, "UTILISATEUR_SUSPENDU")
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = JamesErrorRed)
                                    ) {
                                        Text("Suspendre 24h", fontSize = 11.sp)
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            scope.launch { repository.updateReportStatus(report.id, "REJETÉ") }
                                        }
                                    ) {
                                        Text("Rejeter", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Dossiers Section
            if (dossiers.isNotEmpty()) {
                item {
                    Text(
                        text = "DOSSIERS DE MODÉRATION INTERNE (${dossiers.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                    )
                }
                items(dossiers) { dossier ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "Dossier #${dossier.id.take(8)}", fontWeight = FontWeight.Bold)
                                Text(text = dossier.status, color = JamesWarningAmber, fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Auteur: @${dossier.authorUsername}", fontSize = 13.sp)
                            Text(text = "Motif: ${dossier.reason}", fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                            Text(text = "Aperçu: ${dossier.contentPreview}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    scope.launch { repository.resolveModerationDossier(dossier.id, "RETRAIT_CONTENU") }
                                }) {
                                    Text("Retirer", fontSize = 11.sp)
                                }
                                OutlinedButton(onClick = {
                                    scope.launch { repository.resolveModerationDossier(dossier.id, "AUCUN_PROBLEME") }
                                }) {
                                    Text("Rejeter", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminTeamTab() {
    val team = JamesChatRepository.CONFIGURED_7_ADMINS

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text(text = "Les 7 Administrateurs Officiels de James Chat", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(12.dp))
        }

        items(team) { admin ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    AvatarWithStatus(name = "${admin.firstName} ${admin.lastName}", size = 48.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "${admin.firstName} ${admin.lastName}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            JamesVBadge(size = 14.dp)
                        }
                        Text(text = admin.title, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        Text(text = admin.email, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
