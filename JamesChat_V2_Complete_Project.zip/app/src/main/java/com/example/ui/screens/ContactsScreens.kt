package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.UserEntity
import com.example.data.repository.JamesChatRepository
import com.example.ui.components.AvatarWithStatus
import com.example.ui.components.QuickProfileSheet
import com.example.ui.components.VideoPreviewDialog
import com.example.util.JamesI18n
import kotlinx.coroutines.launch

@Composable
fun ContactsListScreen(
    repository: JamesChatRepository,
    currentLang: AppLanguage,
    onStartChatWithUser: (UserEntity) -> Unit,
    onStartCallWithUser: (UserEntity, Boolean) -> Unit
) {
    val allUsers by repository.dao.getAllUsersFlow().collectAsState(initial = emptyList())
    val currentUser by repository.currentUser.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedUserForSheet by remember { mutableStateOf<UserEntity?>(null) }
    var userForVideoPreview by remember { mutableStateOf<UserEntity?>(null) }
    val scope = rememberCoroutineScope()

    val filteredUsers = remember(allUsers, searchQuery, currentUser) {
        val list = allUsers.filter { it.id != currentUser?.id && it.username.isNotEmpty() }
        if (searchQuery.isBlank()) {
            list
        } else {
            val q = searchQuery.lowercase().trim()
            list.filter {
                it.username.lowercase().contains(q) ||
                it.firstName.lowercase().contains(q) ||
                it.lastName.lowercase().contains(q) ||
                it.bio.lowercase().contains(q)
            }
        }
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(JamesI18n.t("search", currentLang)) },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("contacts_search_input"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            if (filteredUsers.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Aucun contact trouvé",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 15.sp
                    )
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(filteredUsers) { user ->
                        ContactItemRow(
                            user = user,
                            onOpenSheet = { selectedUserForSheet = user },
                            onStartChat = { onStartChatWithUser(user) },
                            onWatchVideo = { userForVideoPreview = user }
                        )
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                            thickness = 0.5.dp,
                            modifier = Modifier.padding(start = 72.dp)
                        )
                    }
                }
            }
        }
    }

    if (selectedUserForSheet != null) {
        QuickProfileSheet(
            targetUser = selectedUserForSheet!!,
            isContact = true,
            isBlocked = false,
            lang = currentLang,
            onDismiss = { selectedUserForSheet = null },
            onSendMessage = { user ->
                selectedUserForSheet = null
                onStartChatWithUser(user)
            },
            onStartCall = { user, isVideo ->
                selectedUserForSheet = null
                onStartCallWithUser(user, isVideo)
            },
            onToggleContact = { user ->
                scope.launch { repository.addContact(user.id) }
            },
            onToggleBlock = { user ->
                scope.launch { repository.setContactBlocked(user.id, true) }
            },
            onReport = { user ->
                scope.launch { repository.reportUser(user, "Signalement rapide", "") }
            },
            onWatchProfileVideo = { user ->
                userForVideoPreview = user
            }
        )
    }

    if (userForVideoPreview != null) {
        VideoPreviewDialog(
            title = "Vidéo de @${userForVideoPreview!!.username}",
            videoUrl = userForVideoPreview!!.profileVideoUrl,
            onDismiss = { userForVideoPreview = null }
        )
    }
}

@Composable
fun ContactItemRow(
    user: UserEntity,
    onOpenSheet: () -> Unit,
    onStartChat: () -> Unit,
    onWatchVideo: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenSheet() }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("contact_row_${user.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AvatarWithStatus(
            name = if (user.firstName.isNotEmpty()) "${user.firstName} ${user.lastName}" else user.username,
            avatarUrl = user.avatarUrl,
            hasProfileVideo = user.profileVideoUrl.isNotEmpty() && user.showVideoOnProfile,
            isOnline = user.isOnline,
            size = 52.dp,
            onClick = {
                if (user.profileVideoUrl.isNotEmpty() && user.showVideoOnProfile && onWatchVideo != null) {
                    onWatchVideo()
                } else {
                    onOpenSheet()
                }
            }
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = if (user.firstName.isNotEmpty()) "${user.firstName} ${user.lastName}" else user.username,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "@${user.username} • ${user.bio.ifEmpty { "Utilisateur James Chat" }}",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }

        IconButton(onClick = onStartChat, modifier = Modifier.testTag("contact_start_chat_btn")) {
            Icon(
                imageVector = Icons.Default.Chat,
                contentDescription = "Message",
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}
