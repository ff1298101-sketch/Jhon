package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.CallRecordEntity
import com.example.data.model.CallState
import com.example.data.model.CallType
import com.example.data.model.UserEntity
import com.example.data.repository.JamesChatRepository
import com.example.ui.components.AvatarWithStatus
import com.example.ui.theme.JamesErrorRed
import com.example.ui.theme.JamesOnlineGreen
import com.example.util.JamesI18n
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CallsListScreen(
    repository: JamesChatRepository,
    currentLang: AppLanguage,
    onStartCall: (UserEntity, Boolean) -> Unit
) {
    val callHistory by repository.dao.getCallHistoryFlow().collectAsState(initial = emptyList())

    Scaffold { padding ->
        if (callHistory.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Aucun appel récent.\nLancez un appel audio ou vidéo haute définition !",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                    modifier = Modifier.padding(24.dp)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                items(callHistory) { call ->
                    CallHistoryRow(
                        call = call,
                        lang = currentLang,
                        onCallBack = { isVideo ->
                            val targetUser = UserEntity(
                                id = call.receiverId,
                                email = "user@jameschat.ht",
                                username = call.receiverName,
                                firstName = call.receiverName,
                                avatarUrl = call.receiverAvatar
                            )
                            onStartCall(targetUser, isVideo)
                        }
                    )
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                        thickness = 0.5.dp,
                        modifier = Modifier.padding(start = 72.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CallHistoryRow(
    call: CallRecordEntity,
    lang: AppLanguage,
    onCallBack: (Boolean) -> Unit
) {
    val timeFormatted = remember(call.timestamp) {
        val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
        sdf.format(Date(call.timestamp))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("call_row_${call.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AvatarWithStatus(
            name = call.receiverName,
            avatarUrl = call.receiverAvatar,
            size = 50.dp,
            showOnlineBadge = false
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = call.receiverName,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(3.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                val (icon, tint) = when (call.callType) {
                    CallType.MISSED.name -> Icons.AutoMirrored.Filled.CallMissed to JamesErrorRed
                    CallType.INCOMING.name -> Icons.AutoMirrored.Filled.CallReceived to JamesOnlineGreen
                    else -> Icons.AutoMirrored.Filled.CallMade to MaterialTheme.colorScheme.primary
                }
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = timeFormatted,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (call.durationSeconds > 0) {
                    Text(
                        text = " • ${call.durationSeconds}s",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        IconButton(onClick = { onCallBack(false) }, modifier = Modifier.testTag("call_back_audio_btn")) {
            Icon(
                imageVector = Icons.Default.Call,
                contentDescription = "Rappeler",
                tint = MaterialTheme.colorScheme.primary
            )
        }

        IconButton(onClick = { onCallBack(true) }, modifier = Modifier.testTag("call_back_video_btn")) {
            Icon(
                imageVector = Icons.Default.Videocam,
                contentDescription = "Appel vidéo",
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun ActiveCallScreen(
    targetUser: UserEntity,
    isVideo: Boolean,
    lang: AppLanguage,
    onEndCall: (Int) -> Unit
) {
    var callState by remember { mutableStateOf(CallState.DIALING) }
    var durationSeconds by remember { mutableIntStateOf(0) }
    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(false) }
    var isCameraFront by remember { mutableStateOf(true) }
    var isCameraOn by remember { mutableStateOf(true) }
    var isReconnecting by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(1200)
        callState = CallState.RINGING
        delay(2200)
        callState = CallState.CONNECTED
        while (true) {
            delay(1000)
            durationSeconds++
        }
    }

    val durationText = remember(durationSeconds) {
        val mins = durationSeconds / 60
        val secs = durationSeconds % 60
        String.format("%02d:%02d", mins, secs)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 40.dp)
            ) {
                AvatarWithStatus(
                    name = if (targetUser.firstName.isNotEmpty()) "${targetUser.firstName} ${targetUser.lastName}" else targetUser.username,
                    avatarUrl = targetUser.avatarUrl,
                    size = 110.dp,
                    showOnlineBadge = false
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (targetUser.firstName.isNotEmpty()) "${targetUser.firstName} ${targetUser.lastName}" else targetUser.username,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Text(
                    text = "@${targetUser.username}",
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.7f)
                )

                Spacer(modifier = Modifier.height(8.dp))

                val stateText = when (callState) {
                    CallState.DIALING -> JamesI18n.t("calling", lang)
                    CallState.RINGING -> JamesI18n.t("ringing", lang)
                    CallState.CONNECTED -> durationText
                    CallState.ENDED -> JamesI18n.t("call_ended", lang)
                }

                Text(
                    text = stateText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (callState == CallState.CONNECTED) JamesOnlineGreen else Color.White.copy(alpha = 0.8f)
                )

                if (isVideo && callState == CallState.CONNECTED) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.Black)
                    ) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = "Flux vidéo WebRTC HD • Chiffré de bout en bout",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 30.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { isMuted = !isMuted },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(if (isMuted) Color.White else Color.White.copy(alpha = 0.2f))
                        .testTag("call_mute_btn")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Micro",
                        tint = if (isMuted) Color.Black else Color.White
                    )
                }

                IconButton(
                    onClick = { onEndCall(durationSeconds) },
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(JamesErrorRed)
                        .testTag("call_hangup_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "Raccrocher",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                if (isVideo) {
                    IconButton(
                        onClick = { isCameraOn = !isCameraOn },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (!isCameraOn) Color.White else Color.White.copy(alpha = 0.2f))
                            .testTag("call_toggle_cam_btn")
                    ) {
                        Icon(
                            imageVector = if (isCameraOn) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            contentDescription = "Activer/Désactiver caméra",
                            tint = if (!isCameraOn) Color.Black else Color.White
                        )
                    }

                    IconButton(
                        onClick = { isCameraFront = !isCameraFront },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f))
                            .testTag("call_flip_cam_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlipCameraAndroid,
                            contentDescription = "Changer caméra",
                            tint = Color.White
                        )
                    }
                } else {
                    IconButton(
                        onClick = { isSpeakerOn = !isSpeakerOn },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (isSpeakerOn) Color.White else Color.White.copy(alpha = 0.2f))
                            .testTag("call_speaker_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Haut-parleur",
                            tint = if (isSpeakerOn) Color.Black else Color.White
                        )
                    }
                }
            }
        }
    }
}
