package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.repository.JamesChatRepository
import com.example.ui.components.AvatarWithStatus
import com.example.ui.components.JamesTeamMemberBadge
import com.example.ui.components.JamesVBadge
import com.example.ui.components.VideoPreviewDialog
import com.example.ui.theme.JamesBluePrimary
import com.example.ui.theme.JamesOnlineGreen
import com.example.util.JamesI18n
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    repository: JamesChatRepository,
    currentLang: AppLanguage,
    onBack: () -> Unit
) {
    val currentUser by repository.currentUser.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var firstName by remember(currentUser) { mutableStateOf(currentUser?.firstName ?: "") }
    var lastName by remember(currentUser) { mutableStateOf(currentUser?.lastName ?: "") }
    var age by remember(currentUser) { mutableStateOf(currentUser?.age?.toString() ?: "") }
    var city by remember(currentUser) { mutableStateOf(currentUser?.city ?: "") }
    var country by remember(currentUser) { mutableStateOf(currentUser?.country ?: "") }
    var bio by remember(currentUser) { mutableStateOf(currentUser?.bio ?: "") }
    var avatarUrl by remember(currentUser) { mutableStateOf(currentUser?.avatarUrl ?: "") }
    var showVideoOnProfile by remember(currentUser) { mutableStateOf(currentUser?.showVideoOnProfile ?: false) }
    var profileVideoUrl by remember(currentUser) { mutableStateOf(currentUser?.profileVideoUrl ?: "") }
    var showVideoPreview by remember { mutableStateOf(false) }
    var saveSuccessMessage by remember { mutableStateOf(false) }
    var showLinkGoogleDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            val uriStr = uri.toString()
            avatarUrl = uriStr
            scope.launch {
                repository.updateProfile(
                    firstName = firstName,
                    lastName = lastName,
                    age = age.toIntOrNull() ?: 0,
                    city = city,
                    country = country,
                    bio = bio,
                    avatarUrl = uriStr,
                    profileVideoUrl = profileVideoUrl,
                    showVideoOnProfile = showVideoOnProfile
                )
                saveSuccessMessage = true
            }
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            val uriStr = uri.toString()
            profileVideoUrl = uriStr
            showVideoOnProfile = true
            scope.launch {
                repository.updateProfile(
                    firstName = firstName,
                    lastName = lastName,
                    age = age.toIntOrNull() ?: 0,
                    city = city,
                    country = country,
                    bio = bio,
                    avatarUrl = avatarUrl,
                    profileVideoUrl = uriStr,
                    showVideoOnProfile = true
                )
                saveSuccessMessage = true
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(JamesI18n.t("tab_profile", currentLang), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("profile_back_btn")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.Center) {
                AvatarWithStatus(
                    name = if (firstName.isNotEmpty()) "$firstName $lastName" else currentUser?.username ?: "Me",
                    avatarUrl = avatarUrl,
                    hasProfileVideo = profileVideoUrl.isNotEmpty() && showVideoOnProfile,
                    size = 104.dp,
                    showOnlineBadge = true,
                    onClick = {
                        if (profileVideoUrl.isNotEmpty() && showVideoOnProfile) {
                            showVideoPreview = true
                        } else {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    }
                )

                IconButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(JamesBluePrimary)
                ) {
                    Icon(imageVector = Icons.Default.CameraAlt, contentDescription = "Changer photo", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "@${currentUser?.username ?: "username"}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                if (currentUser?.isVerified == true) {
                    Spacer(modifier = Modifier.width(6.dp))
                    JamesVBadge(size = 18.dp)
                }
            }

            if (currentUser?.isTeamMember == true) {
                Spacer(modifier = Modifier.height(6.dp))
                JamesTeamMemberBadge()
            }

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(text = "Informations personnelles", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)

                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = firstName,
                            onValueChange = { firstName = it },
                            label = { Text(JamesI18n.t("first_name", currentLang)) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedTextField(
                            value = lastName,
                            onValueChange = { lastName = it },
                            label = { Text(JamesI18n.t("last_name", currentLang)) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    OutlinedTextField(
                        value = age,
                        onValueChange = { age = it },
                        label = { Text(JamesI18n.t("age_label", currentLang)) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = city,
                            onValueChange = { city = it },
                            label = { Text(JamesI18n.t("city_label", currentLang)) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedTextField(
                            value = country,
                            onValueChange = { country = it },
                            label = { Text(JamesI18n.t("country_label", currentLang)) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text(JamesI18n.t("bio_label", currentLang)) },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = JamesI18n.t("profile_media", currentLang),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Chwazi foto oswa videyo ki nan galri aparèy ou an pou w mete sou pwofil ou.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // SECTION 1: PHOTO DE PROFIL
                    Text(
                        text = JamesI18n.t("profile_photo", currentLang),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(JamesI18n.t("choose_photo_gallery", currentLang), fontSize = 12.sp)
                        }

                        if (avatarUrl.isNotEmpty()) {
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        repository.removeProfilePhoto()
                                        avatarUrl = ""
                                        saveSuccessMessage = true
                                    }
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = JamesI18n.t("remove_photo", currentLang),
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // SECTION 2: VIDEO DE PROFIL
                    Text(
                        text = JamesI18n.t("profile_video", currentLang),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = JamesI18n.t("show_video_on_profile", currentLang), fontSize = 13.sp)
                        Switch(
                            checked = showVideoOnProfile,
                            onCheckedChange = {
                                showVideoOnProfile = it
                                scope.launch {
                                    repository.updateProfile(
                                        firstName = firstName,
                                        lastName = lastName,
                                        age = age.toIntOrNull() ?: 0,
                                        city = city,
                                        country = country,
                                        bio = bio,
                                        avatarUrl = avatarUrl,
                                        profileVideoUrl = profileVideoUrl,
                                        showVideoOnProfile = it
                                    )
                                }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                videoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                if (profileVideoUrl.isEmpty()) JamesI18n.t("choose_video_gallery", currentLang)
                                else JamesI18n.t("replace_video", currentLang),
                                fontSize = 12.sp
                            )
                        }

                        if (profileVideoUrl.isNotEmpty()) {
                            Button(
                                onClick = { showVideoPreview = true },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Lire la vidéo", modifier = Modifier.size(16.dp))
                            }

                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        repository.removeProfileVideo()
                                        profileVideoUrl = ""
                                        showVideoOnProfile = false
                                        saveSuccessMessage = true
                                    }
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = JamesI18n.t("remove_video", currentLang),
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    if (profileVideoUrl.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (profileVideoUrl.startsWith("content://") || profileVideoUrl.startsWith("file://"))
                                "🎬 Vidéyo chwazi nan galri telefòn ou (Klike sou flèch la pou w li l)"
                            else "🎬 Vidéyo pwofil anrejistre",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🌐", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Compte Google", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    val isGoogleLinked = currentUser?.email?.endsWith("@gmail.com") == true
                    if (isGoogleLinked) {
                        Text(
                            text = "Compte Google associé : ${currentUser?.email}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "✓ Vos contacts, conversations, paramètres et profil sont conservés.",
                            fontSize = 11.sp,
                            color = JamesOnlineGreen
                        )
                    } else {
                        Text(
                            text = "Associez votre compte Google à votre profil James Chat tout en conservant votre nom d'utilisateur, vos conversations et vos contacts.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { showLinkGoogleDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(text = "Associer mon compte Google", fontSize = 13.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    scope.launch {
                        repository.updateProfile(
                            firstName = firstName,
                            lastName = lastName,
                            age = age.toIntOrNull() ?: 0,
                            city = city,
                            country = country,
                            bio = bio,
                            avatarUrl = avatarUrl,
                            profileVideoUrl = profileVideoUrl,
                            showVideoOnProfile = showVideoOnProfile
                        )
                        saveSuccessMessage = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_profile_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(JamesI18n.t("save_btn", currentLang), fontWeight = FontWeight.Bold)
            }

            if (saveSuccessMessage) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(text = "Modifications enregistrées !", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp)
            }
        }
    }

    if (showVideoPreview) {
        VideoPreviewDialog(
            title = "Vidéo de profil",
            videoUrl = profileVideoUrl,
            onDismiss = { showVideoPreview = false }
        )
    }

    if (showLinkGoogleDialog) {
        var linkEmail by remember { mutableStateOf("") }
        var linkError by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showLinkGoogleDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🌐", fontSize = 20.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Associer un compte Google", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Entrez votre adresse email Google pour associer votre compte James Chat. Vos données, contacts, profil et conversations seront conservés :",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = linkEmail,
                        onValueChange = { linkEmail = it; linkError = null },
                        label = { Text("Adresse email Google (@gmail.com)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (linkError != null) {
                        Text(text = linkError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = linkEmail.trim()
                        if (trimmed.isNotEmpty()) {
                            scope.launch {
                                val res = repository.linkGoogleToCurrentAccount(trimmed)
                                res.fold(
                                    onSuccess = {
                                        showLinkGoogleDialog = false
                                        saveSuccessMessage = true
                                    },
                                    onFailure = {
                                        linkError = it.message ?: "Erreur d'association du compte Google"
                                    }
                                )
                            }
                        }
                    },
                    enabled = linkEmail.contains("@")
                ) {
                    Text("Associer")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLinkGoogleDialog = false }) {
                    Text("Annuler")
                }
            }
        )
    }
}
